# SQL Run Order

Run the scripts in this order when recreating the project environment:

1. `sql/01_data_staging_schema.sql`
2. `sql/02_data_warehouse_schema.sql`
3. `sql/03_calendar_and_base_dimension_loads.sql`
4. `sql/04_initial_etl_load.sql`
5. `sql/05_revenue_fact_initial_load.sql`
6. `sql/06_revenue_fact_refresh_procedures.sql`
7. `sql/07_product_dimension_refresh_scd_type2.sql`
8. `sql/08_category_and_daily_store_aggregates.sql`
9. `sql/09_region_aggregate.sql`

Before running, confirm that the source Zagimore database and schema names match your local MySQL environment.

# Architecture Overview

## Source-to-Warehouse Flow

```text
Zagimore Operational Database
        |
        v
Data Staging Layer
        |
        v
Data Warehouse Layer
        |
        v
Fact and Dimension Tables
        |
        v
Aggregate Reporting Tables
```

## Main Layers

### 1. Operational Source Layer

The source database contains transactional Zagimore business data such as customers, stores, products, vendors, categories, sales transactions, rental transactions, and transaction bridge tables.

### 2. Data Staging Layer

The staging layer prepares the raw transactional data for transformation. It includes staging versions of customer, product, store, calendar, and revenue fact structures.

### 3. Data Warehouse Layer

The warehouse layer stores clean dimensional tables and fact tables that support reporting and analytics.

### 4. Aggregate Layer

Aggregate tables summarize revenue by category, store, region, product, customer, and calendar periods to support faster reporting.

## Core Tables

- `Customer_Dimension`
- `Product_Dimension`
- `Store_Dimension`
- `Calendar_Dimension`
- `Revenue_Fact_Table`
- `CategoryDimension`
- `RegionDimension`
- Aggregate revenue tables

## Refresh Logic

The project includes refresh scripts for revenue fact data and product dimension data. Product dimension refresh logic demonstrates slowly changing dimension handling, where changed product attributes can create a new current record while preserving historical versions.
